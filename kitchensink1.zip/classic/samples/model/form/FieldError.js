Ext.define('KitchenSink.model.form.FieldError', {
    extend: 'KitchenSink.model.Base',
    
    fields: ['msg']
});
