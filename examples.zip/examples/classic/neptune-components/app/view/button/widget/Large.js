Ext.define('Neptune.view.button.widget.Large', {
    extend: 'Neptune.view.button.widget.Small',
    xtype: 'largeButton',
    scale: 'large',
    text: 'Large'
});