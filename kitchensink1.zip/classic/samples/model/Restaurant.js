Ext.define('KitchenSink.model.Restaurant', {
    extend: 'KitchenSink.model.Base',
    fields: ['name', 'cuisine']
});