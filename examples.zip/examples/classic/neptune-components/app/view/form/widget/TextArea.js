Ext.define('Neptune.view.form.widget.TextArea', {
    extend: 'Ext.form.field.TextArea',
    xtype: 'textArea',
    value: Neptune.DummyText.text,
    width: 300,
    height: 100
});