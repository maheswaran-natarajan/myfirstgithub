Ext.define('KitchenSink.model.State', {
    extend: 'KitchenSink.model.Base',

    fields: [
        'abbr',
        'state',
        'description',
        'country'
    ]
});
