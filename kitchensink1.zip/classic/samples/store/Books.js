Ext.define('KitchenSink.store.Books', {
    extend: 'Ext.data.Store',

    alias: 'store.books',
    model: 'KitchenSink.model.grid.Book'
});
