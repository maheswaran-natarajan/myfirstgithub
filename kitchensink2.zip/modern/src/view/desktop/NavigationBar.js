Ext.define('KitchenSink.view.desktop.NavigationBar', {
    extend: 'Ext.TitleBar',
    xtype: 'desktopnavigationbar',
    titleAlign: 'left',

    ui: 'dark'
});
