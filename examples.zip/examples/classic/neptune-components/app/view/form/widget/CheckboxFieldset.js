Ext.define('Neptune.view.form.widget.CheckboxFieldset', {
    extend: 'Neptune.view.form.widget.Fieldset',
    xtype: 'checkboxFieldset',
    checkboxToggle: true
});