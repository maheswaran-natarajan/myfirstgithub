Ext.define('Neptune.view.button.widget.MediumMenu', {
    extend: 'Neptune.view.button.widget.SmallMenu',
    xtype: 'mediumMenuButton',
    scale: 'medium',
    text: 'Medium Menu'
});