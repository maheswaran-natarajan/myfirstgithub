Ext.define('KitchenSink.view.BreadcrumbBar', {
    extend: 'Ext.Toolbar',
    xtype: 'breadcrumb'
});
