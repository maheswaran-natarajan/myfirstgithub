Ext.define('Neptune.view.form.widget.CollapsibleFieldset', {
    extend: 'Neptune.view.form.widget.Fieldset',
    xtype: 'collapsibleFieldset',
    collapsible: true
});