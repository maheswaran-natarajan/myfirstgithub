Ext.define('KitchenSink.model.grid.Office', {
    extend: 'KitchenSink.model.Base',
    fields: ['city', 'totalEmployees', 'manager']
});