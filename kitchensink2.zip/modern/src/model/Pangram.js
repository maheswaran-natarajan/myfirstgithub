Ext.define('KitchenSink.model.Pangram', {
    extend: 'KitchenSink.model.Base',

    fields: [
        { name: 'language', type: 'string' },
        { name: 'text', type: 'string' }
    ]
});