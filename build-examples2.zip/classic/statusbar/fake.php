<?php
    // fake form save
    sleep(2);
    echo '{success:true}';
