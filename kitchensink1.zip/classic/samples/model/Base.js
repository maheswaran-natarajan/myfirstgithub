Ext.define('KitchenSink.model.Base', {
    extend: 'Ext.data.Model',
    schema: {
        namespace: 'KitchenSink.model'
    }
});