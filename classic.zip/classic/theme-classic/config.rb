Compass.add_project_configuration('../../../classic/theme-classic/sass/config.rb')
