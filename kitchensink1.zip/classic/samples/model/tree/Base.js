Ext.define('KitchenSink.model.tree.Base', {
    extend: 'Ext.data.TreeModel',
    requires: [
        'KitchenSink.model.Base'
    ]
});