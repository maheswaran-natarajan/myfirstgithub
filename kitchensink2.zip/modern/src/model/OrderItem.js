Ext.define('KitchenSink.model.OrderItem', {
    extend: 'KitchenSink.model.Base',
    
    fields: ['id', 'quantity', 'price', 'name']
});
