Ext.define('KitchenSink.model.Cars', {
    extend: 'KitchenSink.model.Base',

    fields: [
        {name: 'text', type: 'string'}
    ]
});
