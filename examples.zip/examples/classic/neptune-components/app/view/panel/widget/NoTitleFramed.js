Ext.define('Neptune.view.panel.widget.NoTitleFramed', {
    extend: 'Ext.panel.Panel',
    xtype: 'noTitleFramedPanel',
    frame: true,
    html: Neptune.DummyText.text
});