Ext.define('KitchenSink.view.animations.Cube', {
    extend: 'Ext.Panel',
    cls: 'card card1',
    html: 'Cube Animation'
});
