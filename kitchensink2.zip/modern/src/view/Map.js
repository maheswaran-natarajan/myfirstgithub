/**
 * Demonstrates a Map component
 */
Ext.define('KitchenSink.view.Map', {
    extend: 'Ext.ux.google.Map'
});
