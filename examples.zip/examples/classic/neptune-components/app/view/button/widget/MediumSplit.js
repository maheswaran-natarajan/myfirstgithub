Ext.define('Neptune.view.button.widget.MediumSplit', {
    extend: 'Neptune.view.button.widget.SmallSplit',
    xtype: 'mediumSplitButton',
    scale: 'medium',
    text: 'Medium Split'
});