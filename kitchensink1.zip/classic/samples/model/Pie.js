Ext.define('KitchenSink.model.Pie', {
    extend: 'KitchenSink.model.Base',
    fields: ['id', 'g0', 'g1', 'g2', 'g3', 'g4', 'g5', 'g6', 'name']
});