Ext.define('KitchenSink.view.tablet.NavigationBar', {
    extend: 'Ext.TitleBar',
    xtype: 'tabletnavigationbar',
    titleAlign: 'left',

    ui: 'dark'
});
