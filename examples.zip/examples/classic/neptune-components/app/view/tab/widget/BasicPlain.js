Ext.define('Neptune.view.tab.widget.BasicPlain', {
    extend: 'Neptune.view.tab.widget.Basic',
    xtype: 'basicPlainTabPanel',
    plain: true
}); 
