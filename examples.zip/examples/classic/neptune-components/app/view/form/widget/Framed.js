Ext.define('Neptune.view.form.widget.Framed', {
    extend: 'Neptune.view.form.widget.Basic',
    xtype: 'framedForm',
    title: 'Framed Form',
    frame: true
});