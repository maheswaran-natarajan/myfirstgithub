Ext.define('KitchenSink.model.dd.Simple', {
    extend: 'KitchenSink.model.Base',
    fields: ['name', 'column1', 'column2']    
});
