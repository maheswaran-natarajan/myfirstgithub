Ext.define('KitchenSink.model.StandardChart', {
    extend: 'KitchenSink.model.Base',
    fields: ['name', 'data1', 'data2', 'data3', 'data4', 'data5', 'data6', 'data7', 'data8', 'data9']
});