Ext.define('KitchenSink.view.ContentPanel', {
    extend: 'Ext.Container',
    xtype: 'contentPanel',
    classCls: 'main-nav',

    header: {
        hidden: true
    }
});
