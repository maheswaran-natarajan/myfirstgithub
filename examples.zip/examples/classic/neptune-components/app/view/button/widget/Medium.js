Ext.define('Neptune.view.button.widget.Medium', {
    extend: 'Neptune.view.button.widget.Small',
    xtype: 'mediumButton',
    scale: 'medium',
    text: 'Medium'
});