Ext.application({
    name: 'Neptune',
    autoCreateViewport: true,
    requires: [
        'Neptune.*'
    ],
    controllers: ['Main']
});
